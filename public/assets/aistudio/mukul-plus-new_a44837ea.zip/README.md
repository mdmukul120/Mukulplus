# Mukul Plus (মুকুল প্লাস)

Live TV ও Movies/Series স্ট্রিমিং অ্যাপ — Kotlin, Jetpack Compose ও Media3 (ExoPlayer) দিয়ে তৈরি।

## ফিচার
- **Live TV**: ক্যাটাগরি ফিল্টার, সার্চ, ফিচার্ড চ্যানেল ব্যানার, ৩-কলাম চ্যানেল গ্রিড, ফুলস্ক্রিন প্লেয়ার
- **Movies & Series**: অটো-স্লাইড হিরো ক্যারোসেল, Movies/Series ফিল্টার, ক্যাটাগরি রো, সার্চ, ডিটেইল বটম শিট (সার্ভার সিলেক্ট সহ)
- ফ্লোটিং নেভিগেশন বার, ডার্ক + গোল্ড থিম

## Build
GitHub এ push করলে `.github/workflows/build-and-release.yml` APK বানাবে, অথবা লোকালে `./gradlew assembleDebug`।
