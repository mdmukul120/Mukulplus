package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.LiveTv
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ChannelItem
import com.example.data.model.MovieItem
import com.example.data.model.PlayerItem
import com.example.data.repository.MukulRepository
import com.example.ui.player.MoviePlayerView
import com.example.ui.player.MukulVideoPlayer
import com.example.ui.screens.LiveTvScreen
import com.example.ui.screens.MoviesScreen
import com.example.ui.theme.*
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MukulPlusTheme {
                MukulApp()
            }
        }
    }
}

enum class AppTab(val title: String, val icon: ImageVector) {
    LIVE_TV("Live TV", Icons.Rounded.LiveTv),
    MOVIES("Movies", Icons.Rounded.Movie)
}

@Composable
fun MukulApp() {
    val context = LocalContext.current
    val repository = remember { MukulRepository(context) }
    val scope = rememberCoroutineScope()

    val channels by repository.channels.collectAsStateWithLifecycle()
    val categories by repository.categories.collectAsStateWithLifecycle()
    val isLoading by repository.isLoading.collectAsStateWithLifecycle()

    var currentTab by remember { mutableStateOf(AppTab.LIVE_TV) }
    var activeChannel by remember { mutableStateOf<ChannelItem?>(null) }
    var activeMovie by remember { mutableStateOf<Pair<MovieItem, PlayerItem?>?>(null) }

    LaunchedEffect(Unit) { repository.fetchAllData() }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MukulDarkBg)
    ) {
        val channel = activeChannel
        val movie = activeMovie
        when {
            channel != null -> MukulVideoPlayer(
                currentChannel = channel,
                allChannels = channels,
                onSelectChannel = { activeChannel = it },
                onClosePlayer = { activeChannel = null }
            )

            movie != null -> MoviePlayerView(
                movie = movie.first,
                selectedPlayer = movie.second,
                onClosePlayer = { activeMovie = null }
            )

            else -> {
                when (currentTab) {
                    AppTab.LIVE_TV -> LiveTvScreen(
                        channels = channels,
                        isLoading = isLoading,
                        onPlayChannel = { activeChannel = it },
                        onRefresh = { scope.launch { repository.fetchAllData(forceRefresh = true) } }
                    )

                    AppTab.MOVIES -> MoviesScreen(
                        categories = categories,
                        isLoading = isLoading,
                        onPlayMovie = { m, p -> activeMovie = Pair(m, p) }
                    )
                }

                FloatingNavBar(
                    current = currentTab,
                    onSelect = { currentTab = it },
                    modifier = Modifier.align(Alignment.BottomCenter)
                )
            }
        }
    }
}

@Composable
private fun FloatingNavBar(
    current: AppTab,
    onSelect: (AppTab) -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(32.dp)
    Row(
        modifier = modifier
            .navigationBarsPadding()
            .padding(bottom = 16.dp)
            .shadow(20.dp, shape, ambientColor = Color.Black, spotColor = Color.Black)
            .clip(shape)
            .background(MukulDarkSurface.copy(alpha = 0.96f))
            .border(1.dp, MukulBorder, shape)
            .padding(6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AppTab.values().forEach { tab ->
            val selected = tab == current
            val bg by animateColorAsState(
                targetValue = if (selected) MukulGold else Color.Transparent,
                animationSpec = tween(250),
                label = "navBg"
            )
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(26.dp))
                    .background(bg)
                    .clickable { onSelect(tab) }
                    .padding(horizontal = 22.dp, vertical = 12.dp)
                    .animateContentSize()
                    .testTag("nav_item_${tab.name.lowercase()}"),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = tab.icon,
                    contentDescription = tab.title,
                    tint = if (selected) MukulDarkBg else MukulTextMuted,
                    modifier = Modifier.size(24.dp)
                )
                AnimatedVisibility(
                    visible = selected,
                    enter = fadeIn(tween(200)) + expandHorizontally(),
                    exit = fadeOut(tween(100)) + shrinkHorizontally()
                ) {
                    Text(
                        text = tab.title,
                        color = MukulDarkBg,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.ExtraBold,
                        maxLines = 1,
                        modifier = Modifier.padding(start = 8.dp)
                    )
                }
            }
        }
    }
}
