package com.example.data.repository

import android.content.Context
import com.example.data.api.NetworkClient
import com.example.data.model.CatalogCategory
import com.example.data.model.ChannelItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

class MukulRepository(@Suppress("UNUSED_PARAMETER") context: Context) {

    private val _channels = MutableStateFlow<List<ChannelItem>>(emptyList())
    val channels: StateFlow<List<ChannelItem>> = _channels.asStateFlow()

    private val _categories = MutableStateFlow<List<CatalogCategory>>(emptyList())
    val categories: StateFlow<List<CatalogCategory>> = _categories.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    suspend fun fetchAllData(forceRefresh: Boolean = false) {
        if (!forceRefresh && _channels.value.isNotEmpty()) return

        _isLoading.value = true

        withContext(Dispatchers.IO) {
            try {
                val feed = NetworkClient.iptvService.getLiveFeed()
                _channels.value = feed.channels.filter { it.streamUrl.isNotBlank() }
            } catch (e: Exception) {
            }

            try {
                val env = NetworkClient.netStreamService.getCatalog()
                _categories.value = env.result?.full ?: emptyList()
            } catch (e: Exception) {
            }
        }

        _isLoading.value = false
    }
}
