package com.example.data.api

import com.example.data.model.*
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

interface IptvService {
    @GET("api/iptv/live.json")
    suspend fun getLiveFeed(): IptvFeed
}

interface NetStreamService {
    @GET("catalog")
    suspend fun getCatalog(): CatalogEnvelope
}

object NetworkClient {
    val okHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .addInterceptor(HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BASIC
            })
            .build()
    }

    private val moshiConverterFactory by lazy {
        MoshiConverterFactory.create()
    }

    val iptvService: IptvService by lazy {
        Retrofit.Builder()
            .baseUrl("https://mukul-ott.ai.studio/")
            .client(okHttpClient)
            .addConverterFactory(moshiConverterFactory)
            .build()
            .create(IptvService::class.java)
    }

    val netStreamService: NetStreamService by lazy {
        Retrofit.Builder()
            .baseUrl("https://mapi.elochkaigolochla.com/api/v1/")
            .client(okHttpClient)
            .addConverterFactory(moshiConverterFactory)
            .build()
            .create(NetStreamService::class.java)
    }
}
